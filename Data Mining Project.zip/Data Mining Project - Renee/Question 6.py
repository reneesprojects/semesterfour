import pandas as pd
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

file_path = '/Users/renren/Desktop/Dataset 2.xlsx' 
df = pd.read_excel(file_path)

print(df.head())
print(df.columns)  

# Set the target variable 
target_column = 'Trouble Sleeping'

# Checking if the target column exists
if target_column not in df.columns:
    print(f"Column '{target_column}' not found. Columns available: {df.columns}")
else:
    # Encoding the target column ('Trouble Sleeping') (assuming binary classification: 0 or 1)
    label_encoder = LabelEncoder()
    df[target_column] = label_encoder.fit_transform(df[target_column])

# Split the dataset into features (X) and target (y)
X = df.drop(columns=[target_column])  
y = df[target_column]  

# Use Chi-square test to select features
# Chi-square test works on non-negative integer values, so let's make sure the features are in that form
X_encoded = X.apply(LabelEncoder().fit_transform)

# Perform Chi-square test and select top k features
chi2_selector = SelectKBest(chi2, k=10)  
X_selected = chi2_selector.fit_transform(X_encoded, y)

# Show the scores and p-values for the features
chi2_scores = chi2_selector.scores_
chi2_pvalues = chi2_selector.pvalues_

# Create a DataFrame with feature names and their respective p-values
chi2_results = pd.DataFrame({
    'Feature': X.columns,
    'Chi2 Score': chi2_scores,
    'P-value': chi2_pvalues
})

# Sort by p-value to select the most significant features
chi2_results = chi2_results.sort_values(by='P-value', ascending=True)

# Show the Chi-square results table
print("\nChi-square Results (Top 10 Features):")
print(chi2_results.head(10))

# k-NN classifier
X_train, X_test, y_train, y_test = train_test_split(X_encoded[chi2_results['Feature'].head(10)], y, test_size=0.2, random_state=42)

knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)
y_pred = knn.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)

print(f"Classification accuracy using selected 10 features: {accuracy:.4f}")




