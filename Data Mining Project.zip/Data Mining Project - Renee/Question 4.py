import pandas as pd
import scipy.stats as stats
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

file_path = "/Users/renren/Desktop/Data Mining Project Datasheet.xlsx"
df = pd.read_excel(file_path)

df.columns = ["ID", "Diagnosis"] + [f"Feature_{i}" for i in range(1, 31)]

# Drop the ID column as it is not relevant for prediction
df.drop(columns=["ID"], inplace=True)

# Encode the 'Diagnosis' column (M = 1 for malignant, B = 0 for benign)
label_encoder = LabelEncoder()
df["Diagnosis"] = label_encoder.fit_transform(df["Diagnosis"])

# Split the data into malignant and benign groups
malignant_group = df[df["Diagnosis"] == 1]
benign_group = df[df["Diagnosis"] == 0]

# Perform Student's t-test for each feature
t_test_results = []
for feature in df.columns[1:]:  # Exclude "Diagnosis" column
    t_stat, p_value = stats.ttest_ind(malignant_group[feature], benign_group[feature], equal_var=False)
    t_test_results.append((feature, p_value))

# Create a table of feature names and p-values
t_test_df = pd.DataFrame(t_test_results, columns=["Feature", "p-value"])

# Select top 10 features with the lowest p-values
top_features = t_test_df.nsmallest(10, "p-value")["Feature"].tolist()

# Split the data into training and testing sets (80% training, 20% testing)
X_all = df.drop(columns=["Diagnosis"])
X_selected = df[top_features]  # Using only the selected features
y = df["Diagnosis"]

X_train_all, X_test_all, y_train, y_test = train_test_split(X_all, y, test_size=0.2, random_state=42, stratify=y)
X_train_selected, X_test_selected = X_train_all[top_features], X_test_all[top_features]  # Use same train-test split

# Standardize features
scaler_all = StandardScaler()
X_train_all_scaled = scaler_all.fit_transform(X_train_all)
X_test_all_scaled = scaler_all.transform(X_test_all)

scaler_selected = StandardScaler()
X_train_selected_scaled = scaler_selected.fit_transform(X_train_selected)
X_test_selected_scaled = scaler_selected.transform(X_test_selected)

# Train k-NN classifier with all 30 features
knn_all = KNeighborsClassifier(n_neighbors=5)
knn_all.fit(X_train_all_scaled, y_train)
y_pred_all = knn_all.predict(X_test_all_scaled)
accuracy_all = accuracy_score(y_test, y_pred_all)

# Train k-NN classifier with selected features
knn_selected = KNeighborsClassifier(n_neighbors=5)
knn_selected.fit(X_train_selected_scaled, y_train)
y_pred_selected = knn_selected.predict(X_test_selected_scaled)
accuracy_selected = accuracy_score(y_test, y_pred_selected)

print("\nT-Test Results Table:")
print(t_test_df)

print("\nClassification Accuracy:")
print(f"Accuracy using all 30 features: {accuracy_all:.2%}")
print(f"Accuracy using selected features: {accuracy_selected:.2%}")
