import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

file_path = "/Users/renren/Desktop/Data Mining Project Datasheet.xlsx"  
df = pd.read_excel(file_path)

#Drop the 'Patient ID' column as it is not relevant for prediction
df.drop(columns=["Patient ID"], inplace=True)

#Encode the 'Diagnosis' column (M = 1 for Malignant, B = 0 for Benign)
label_encoder = LabelEncoder()
df["Diagnosis"] = label_encoder.fit_transform(df["Diagnosis"])

#Extract features and target variable
X = df.drop(columns=["Diagnosis"])  
y = df["Diagnosis"] 

#Split the data into training (80%) and testing (20%) sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

#Standardize features (mean=0, variance=1) to improve k-NN performance
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

#Train k-Nearest Neighbors (k-NN) model with k=5
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train_scaled, y_train)

#Make predictions on the test set
y_pred = knn.predict(X_test_scaled)

accuracy = accuracy_score(y_test, y_pred)

print(f"k-NN Model Accuracy: {accuracy:.4f}")




