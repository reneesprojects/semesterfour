#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: renren
"""

import pandas as pd

# Load the dataset 
file_path = "/Users/renren/Desktop/Cirrhosis for Python .xlsx"  
df = pd.read_excel(file_path)  

# Define the columns to impute with median
columns_median = ["Cholesterol", "Copper", "Tryglicerides"]

# Define the column to impute with mean
columns_mean = ["Platelets"]

# Impute using median for right-skewed distributions
for column in columns_median:
    if column in df.columns:
        median_value = df[column].median()
        df[column].fillna(median_value, inplace=True)
        print(f"Imputed missing values in {column} using median: {median_value}")

# Impute using mean for Platelets
for column in columns_mean:
    if column in df.columns:
        mean_value = df[column].mean()
        df[column].fillna(mean_value, inplace=True)
        print(f"Imputed missing values in {column} using mean: {mean_value}")

# Save the fully imputed dataset
final_file_path = "//Users/renren/Desktop/all_data_imputed.xlsx"
df.to_excel(final_file_path, index=False)

print(f"Final imputed dataset saved at: {final_file_path}")