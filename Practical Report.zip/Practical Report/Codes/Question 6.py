#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: renren
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset 
file_path = "/Users/renren/Desktop/all_data_imputed.xlsx"  
df = pd.read_excel(file_path)

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset 
file_path = "/Users/renren/Desktop/all_data_imputed.xlsx"  
df = pd.read_excel(file_path)

# Define key variables for visualization
key_variables = ["Albumin", "Prothrombin", "Alk_Phos", "Bilirubin"]
stage_column = "Stage"  

# Create histograms to visualize distributions
for column in key_variables:
    if column in df.columns:
        plt.figure(figsize=(8,5))
        sns.histplot(data=df, x=column, bins=20, kde=True, hue=stage_column, palette="viridis")
        plt.title(f"Histogram of {column} by Histological Stage")
        plt.xlabel(column)
        plt.ylabel("Count")
        plt.legend(title="Stage")
        plt.show()

# Create boxplots to compare histological stages for each variable
for column in key_variables:
    if column in df.columns:
        plt.figure(figsize=(8,5))
        sns.boxplot(x=df[stage_column].astype(str), y=df[column], palette="viridis")
        plt.title(f"Boxplot of {column} by Histological Stage")
        plt.xlabel("Stage")
        plt.ylabel(column)
        plt.show()

# Create scatter plots to visualize potential class separation
for column in key_variables:
    if column in df.columns:
        plt.figure(figsize=(8,5))
        sns.scatterplot(x=df[stage_column], y=df[column], hue=df[stage_column].astype(str), palette="viridis", alpha=0.6)
        plt.title(f"Scatter Plot of {column} by Histological Stage")
        plt.xlabel("Stage")
        plt.ylabel(column)
        plt.show()

# Create a correlation heatmap to check relationships
plt.figure(figsize=(10,6))
corr_matrix = df[key_variables + [stage_column]].corr()
sns.heatmap(corr_matrix, annot=True, cmap="coolwarm", fmt=".2f", linewidths=0.5)
plt.title("Correlation Heatmap of Key Variables")
plt.show()
