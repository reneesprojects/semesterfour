#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: renren
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import LeaveOneOut, cross_val_score
from sklearn.preprocessing import StandardScaler
from scipy import stats

# Load dataset
df = pd.read_excel('/Users/renren/Downloads/student data folder 2/cirrhosis_cleaned_for_feat_select.xlsx')

# Selecting features and target variable
df_data = df.iloc[:, 1:12]  # Feature columns
df_label = df.iloc[:, 12]  # Target variable

X = df_data.to_numpy()
y = np.ravel(df_label)  # Convert labels to 1D array

# Scale the data
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Perform t-test and organize data by p-value
num_of_features = X.shape[1]
p_values = np.ones(num_of_features)

for i in range(num_of_features):
    feature_from_dead = X[y == 1, i]  # Assuming 1 = Dead
    feature_from_survived = X[y == 0, i]  # Assuming 0 = Survived
    t_stat, p_value = stats.ttest_ind(feature_from_survived, feature_from_dead, equal_var=False)
    p_values[i] = p_value

# Create a DataFrame for p-values vs feature number
p_value_df = pd.DataFrame({'Feature': df_data.columns, 'p_value': p_values})
p_value_df = p_value_df.sort_values(by=['p_value'], ascending=True).reset_index(drop=True)

# Backward Feature Elimination using Random Forest & LOOCV
loo = LeaveOneOut()
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)

accuracy_results = []
selected_features = list(df_data.columns)

while len(selected_features) > 1:
    # Train model using selected features
    X_selected = df[selected_features].to_numpy()
    scores = cross_val_score(rf_model, X_selected, y, cv=loo, scoring='accuracy')
    avg_accuracy = np.mean(scores)
    accuracy_results.append((len(selected_features), avg_accuracy))

    print(f"Number of features = {len(selected_features)}, Accuracy: {avg_accuracy:.4f}")

    # Remove the least significant feature (highest p-value)
    feature_to_remove = p_value_df.iloc[-1]["Feature"]
    selected_features.remove(feature_to_remove)
    p_value_df = p_value_df.iloc[:-1]  # Remove last row

# Store results in a DataFrame
results_df = pd.DataFrame(accuracy_results, columns=["Number of Features", "Accuracy"])
