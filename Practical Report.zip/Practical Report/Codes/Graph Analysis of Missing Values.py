#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@author: renren
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset 
file_path = "/Users/renren/Desktop/Cirrhosis for Python .xlsx"  
df = pd.read_excel(file_path) 

# Define the columns to analyze
columns_to_analyze = ["Cholesterol", "Copper", "Tryglicerides", "Platelets"]

for column in columns_to_analyze:
    if column in df.columns:
        # Check for missing values before visualization
        missing_before = df[column].isnull().sum()
        print(f"Missing values in {column} before visualization: {missing_before}")

        # Plot distribution before imputation
        plt.figure(figsize=(15,5))
        plt.suptitle(f"Analysis of {column} Before Imputation", fontsize=14)
        
        plt.subplot(1,3,1)
        sns.histplot(df[column], bins=20, kde=True)
        plt.title(f"Histogram of {column}")

        plt.subplot(1,3,2)
        sns.boxplot(y=df[column])
        plt.title(f"Boxplot of {column}")

        plt.subplot(1,3,3)
        plt.scatter(range(len(df[column])), df[column], alpha=0.5)
        plt.title(f"Scatter Plot of {column}")
        plt.ylabel(f"{column} Levels")
        plt.show()